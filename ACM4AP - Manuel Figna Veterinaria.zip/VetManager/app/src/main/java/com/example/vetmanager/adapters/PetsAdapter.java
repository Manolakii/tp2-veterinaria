package com.example.vetmanager.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.vetmanager.R;
import com.example.vetmanager.models.Pet;
import java.util.List;

public class PetsAdapter extends RecyclerView.Adapter<PetsAdapter.PetViewHolder> {

    private List<Pet> petsList;
    private OnPetClickListener listener;

    public interface OnPetClickListener {
        void onEditClick(Pet pet);
        void onDeleteClick(Pet pet);
    }

    public PetsAdapter(List<Pet> petsList, OnPetClickListener listener) {
        this.petsList = petsList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public PetViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_pet, parent, false);
        return new PetViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PetViewHolder holder, int position) {
        Pet pet = petsList.get(position);
        holder.bind(pet);
    }

    @Override
    public int getItemCount() {
        return petsList.size();
    }

    class PetViewHolder extends RecyclerView.ViewHolder {
        TextView tvPetName, tvPetSpecies, tvPetBreed, tvPetAge;
        ImageButton btnEdit, btnDelete;

        PetViewHolder(@NonNull View itemView) {
            super(itemView);
            tvPetName = itemView.findViewById(R.id.tvPetName);
            tvPetSpecies = itemView.findViewById(R.id.tvPetSpecies);
            tvPetBreed = itemView.findViewById(R.id.tvPetBreed);
            tvPetAge = itemView.findViewById(R.id.tvPetAge);
            btnEdit = itemView.findViewById(R.id.btnEdit);
            btnDelete = itemView.findViewById(R.id.btnDelete);
        }

        void bind(Pet pet) {
            tvPetName.setText(pet.getName());
            tvPetSpecies.setText(pet.getSpecies());
            tvPetBreed.setText("Raza: " + pet.getBreed());
            tvPetAge.setText("Edad: " + pet.getAge());

            btnEdit.setOnClickListener(v -> listener.onEditClick(pet));
            btnDelete.setOnClickListener(v -> listener.onDeleteClick(pet));
        }
    }
}