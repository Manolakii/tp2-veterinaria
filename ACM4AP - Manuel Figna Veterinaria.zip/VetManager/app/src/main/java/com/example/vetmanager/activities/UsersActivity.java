package com.example.vetmanager.activities;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.vetmanager.R;
import com.example.vetmanager.adapters.UsersAdapter;
import com.example.vetmanager.models.User;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class UsersActivity extends AppCompatActivity implements UsersAdapter.OnUserClickListener {

    private RecyclerView recyclerView;
    private UsersAdapter adapter;
    private List<User> usersList;
    private FloatingActionButton fabAddUser;
    private ProgressBar progressBar;
    private FirebaseFirestore db;
    private ExecutorService executorService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_users);

        initializeViews();
        db = FirebaseFirestore.getInstance();
        executorService = Executors.newSingleThreadExecutor();

        setupRecyclerView();
        loadUsers();

        fabAddUser.setOnClickListener(v -> showAddUserDialog());
    }

    private void initializeViews() {
        recyclerView = findViewById(R.id.recyclerViewUsers);
        fabAddUser = findViewById(R.id.fabAddUser);
        progressBar = findViewById(R.id.progressBar);
    }

    private void setupRecyclerView() {
        usersList = new ArrayList<>();
        adapter = new UsersAdapter(usersList, this);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);
    }

    private void loadUsers() {
        progressBar.setVisibility(View.VISIBLE);

        executorService.execute(() -> {
            db.collection("users")
                    .get()
                    .addOnCompleteListener(task -> {
                        runOnUiThread(() -> {
                            progressBar.setVisibility(View.GONE);
                            if (task.isSuccessful() && task.getResult() != null) {
                                usersList.clear();
                                for (QueryDocumentSnapshot document : task.getResult()) {
                                    User user = document.toObject(User.class);
                                    usersList.add(user);
                                }
                                adapter.notifyDataSetChanged();

                                if (usersList.isEmpty()) {
                                    Toast.makeText(UsersActivity.this,
                                            getString(R.string.no_data),
                                            Toast.LENGTH_SHORT).show();
                                }
                            } else {
                                Toast.makeText(UsersActivity.this,
                                        getString(R.string.error),
                                        Toast.LENGTH_SHORT).show();
                            }
                        });
                    });
        });
    }

    private void showAddUserDialog() {
        Toast.makeText(this, "Usa la pantalla de registro para agregar nuevos usuarios",
                Toast.LENGTH_LONG).show();
    }

    @Override
    public void onEditClick(User user) {
        showEditUserDialog(user);
    }

    private void showEditUserDialog(User user) {
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_edit_user, null);

        EditText etFullName = dialogView.findViewById(R.id.etFullName);
        EditText etPhone = dialogView.findViewById(R.id.etPhone);
        EditText etAddress = dialogView.findViewById(R.id.etAddress);
        RadioGroup rgRole = dialogView.findViewById(R.id.rgRole);

        // Cargar datos actuales
        etFullName.setText(user.getFullName());
        etPhone.setText(user.getPhone());
        etAddress.setText(user.getAddress());

        // Seleccionar rol actual
        if ("admin".equals(user.getRole())) {
            rgRole.check(R.id.rbAdmin);
        } else if ("vet".equals(user.getRole())) {
            rgRole.check(R.id.rbVet);
        } else {
            rgRole.check(R.id.rbClient);
        }

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(getString(R.string.edit_user))
                .setView(dialogView)
                .setPositiveButton(getString(R.string.update), null)
                .setNegativeButton(getString(R.string.cancel), null)
                .create();

        dialog.setOnShowListener(dialogInterface -> {
            Button btnUpdate = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
            btnUpdate.setOnClickListener(v -> {
                user.setFullName(etFullName.getText().toString().trim());
                user.setPhone(etPhone.getText().toString().trim());
                user.setAddress(etAddress.getText().toString().trim());

                int selectedRoleId = rgRole.getCheckedRadioButtonId();
                RadioButton rbRole = dialogView.findViewById(selectedRoleId);
                user.setRole(rbRole.getText().toString().toLowerCase());

                updateUser(user);
                dialog.dismiss();
            });
        });

        dialog.show();
    }

    private void updateUser(User user) {
        progressBar.setVisibility(View.VISIBLE);

        executorService.execute(() -> {
            db.collection("users")
                    .document(user.getUid())
                    .set(user)
                    .addOnSuccessListener(aVoid -> {
                        runOnUiThread(() -> {
                            progressBar.setVisibility(View.GONE);
                            Toast.makeText(UsersActivity.this,
                                    getString(R.string.success),
                                    Toast.LENGTH_SHORT).show();
                            loadUsers();
                        });
                    })
                    .addOnFailureListener(e -> {
                        runOnUiThread(() -> {
                            progressBar.setVisibility(View.GONE);
                            Toast.makeText(UsersActivity.this,
                                    getString(R.string.error),
                                    Toast.LENGTH_SHORT).show();
                        });
                    });
        });
    }

    @Override
    public void onDeleteClick(User user) {
        new AlertDialog.Builder(this)
                .setTitle(getString(R.string.delete_user))
                .setMessage(getString(R.string.delete_confirmation))
                .setPositiveButton(getString(R.string.yes), (dialog, which) -> deleteUser(user))
                .setNegativeButton(getString(R.string.no), null)
                .show();
    }

    private void deleteUser(User user) {
        progressBar.setVisibility(View.VISIBLE);

        executorService.execute(() -> {
            db.collection("users")
                    .document(user.getUid())
                    .delete()
                    .addOnSuccessListener(aVoid -> {
                        runOnUiThread(() -> {
                            progressBar.setVisibility(View.GONE);
                            Toast.makeText(UsersActivity.this,
                                    getString(R.string.success),
                                    Toast.LENGTH_SHORT).show();
                            loadUsers();
                        });
                    })
                    .addOnFailureListener(e -> {
                        runOnUiThread(() -> {
                            progressBar.setVisibility(View.GONE);
                            Toast.makeText(UsersActivity.this,
                                    getString(R.string.error),
                                    Toast.LENGTH_SHORT).show();
                        });
                    });
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (executorService != null && !executorService.isShutdown()) {
            executorService.shutdown();
        }
    }
}