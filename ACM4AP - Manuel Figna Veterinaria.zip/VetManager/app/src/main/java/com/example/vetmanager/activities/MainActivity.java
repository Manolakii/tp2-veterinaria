package com.example.vetmanager.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import com.example.vetmanager.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

public class MainActivity extends AppCompatActivity {

    private TextView tvWelcome;
    private Button btnManagePets, btnManageAppointments, btnManageUsers, btnLogout;
    private FirebaseAuth mAuth;
    private FirebaseFirestore db;
    private String userRole = "client";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initializeViews();
        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        loadUserData();
        setupListeners();
    }

    private void initializeViews() {
        tvWelcome = findViewById(R.id.tvWelcome);
        btnManagePets = findViewById(R.id.btnManagePets);
        btnManageAppointments = findViewById(R.id.btnManageAppointments);
        btnManageUsers = findViewById(R.id.btnManageUsers);
        btnLogout = findViewById(R.id.btnLogout);
    }

    private void loadUserData() {
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser != null) {
            db.collection("users")
                    .document(currentUser.getUid())
                    .get()
                    .addOnSuccessListener(documentSnapshot -> {
                        if (documentSnapshot.exists()) {
                            String fullName = documentSnapshot.getString("fullName");
                            userRole = documentSnapshot.getString("role");

                            tvWelcome.setText(getString(R.string.welcome) + ", " + fullName);

                            // Solo admin puede gestionar usuarios
                            if (!"admin".equals(userRole)) {
                                btnManageUsers.setVisibility(android.view.View.GONE);
                            }
                        }
                    })
                    .addOnFailureListener(e -> {
                        Toast.makeText(this, getString(R.string.error), Toast.LENGTH_SHORT).show();
                    });
        }
    }

    private void setupListeners() {
        btnManagePets.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, PetsActivity.class);
            startActivity(intent);
        });

        btnManageAppointments.setOnClickListener(v -> {
            Toast.makeText(this, "Función de citas en desarrollo", Toast.LENGTH_SHORT).show();
        });

        btnManageUsers.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, UsersActivity.class);
            startActivity(intent);
        });

        btnLogout.setOnClickListener(v -> showLogoutDialog());
    }

    private void showLogoutDialog() {
        new AlertDialog.Builder(this)
                .setTitle(getString(R.string.logout))
                .setMessage("¿Estás seguro de cerrar sesión?")
                .setPositiveButton(getString(R.string.yes), (dialog, which) -> logout())
                .setNegativeButton(getString(R.string.no), null)
                .show();
    }

    private void logout() {
        mAuth.signOut();
        Intent intent = new Intent(MainActivity.this, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }
}