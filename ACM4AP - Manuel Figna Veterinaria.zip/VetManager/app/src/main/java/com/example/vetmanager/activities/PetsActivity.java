package com.example.vetmanager.activities;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.vetmanager.R;
import com.example.vetmanager.adapters.PetsAdapter;
import com.example.vetmanager.models.Pet;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class PetsActivity extends AppCompatActivity implements PetsAdapter.OnPetClickListener {

    private RecyclerView recyclerView;
    private PetsAdapter adapter;
    private List<Pet> petsList;
    private FloatingActionButton fabAddPet;
    private ProgressBar progressBar;
    private FirebaseFirestore db;
    private FirebaseAuth mAuth;
    private ExecutorService executorService;
    private String currentUserId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pets);

        initializeViews();
        db = FirebaseFirestore.getInstance();
        mAuth = FirebaseAuth.getInstance();
        executorService = Executors.newSingleThreadExecutor();
        currentUserId = mAuth.getCurrentUser() != null ? mAuth.getCurrentUser().getUid() : "";

        setupRecyclerView();
        loadPets();

        fabAddPet.setOnClickListener(v -> showAddPetDialog());
    }

    private void initializeViews() {
        recyclerView = findViewById(R.id.recyclerViewPets);
        fabAddPet = findViewById(R.id.fabAddPet);
        progressBar = findViewById(R.id.progressBar);
    }

    private void setupRecyclerView() {
        petsList = new ArrayList<>();
        adapter = new PetsAdapter(petsList, this);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);
    }

    private void loadPets() {
        progressBar.setVisibility(View.VISIBLE);

        executorService.execute(() -> {
            db.collection("pets")
                    .whereEqualTo("ownerId", currentUserId)
                    .get()
                    .addOnCompleteListener(task -> {
                        runOnUiThread(() -> {
                            progressBar.setVisibility(View.GONE);
                            if (task.isSuccessful() && task.getResult() != null) {
                                petsList.clear();
                                for (QueryDocumentSnapshot document : task.getResult()) {
                                    Pet pet = document.toObject(Pet.class);
                                    pet.setId(document.getId());
                                    petsList.add(pet);
                                }
                                adapter.notifyDataSetChanged();

                                if (petsList.isEmpty()) {
                                    Toast.makeText(PetsActivity.this,
                                            getString(R.string.no_data),
                                            Toast.LENGTH_SHORT).show();
                                }
                            } else {
                                Toast.makeText(PetsActivity.this,
                                        getString(R.string.error),
                                        Toast.LENGTH_SHORT).show();
                            }
                        });
                    });
        });
    }

    private void showAddPetDialog() {
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_add_pet, null);

        EditText etName = dialogView.findViewById(R.id.etPetName);
        EditText etBreed = dialogView.findViewById(R.id.etPetBreed);
        EditText etAge = dialogView.findViewById(R.id.etPetAge);
        EditText etMedicalHistory = dialogView.findViewById(R.id.etMedicalHistory);
        RadioGroup rgSpecies = dialogView.findViewById(R.id.rgSpecies);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(getString(R.string.add_pet))
                .setView(dialogView)
                .setPositiveButton(getString(R.string.save), null)
                .setNegativeButton(getString(R.string.cancel), null)
                .create();

        dialog.setOnShowListener(dialogInterface -> {
            Button btnSave = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
            btnSave.setOnClickListener(v -> {
                String name = etName.getText().toString().trim();
                String breed = etBreed.getText().toString().trim();
                String age = etAge.getText().toString().trim();
                String medicalHistory = etMedicalHistory.getText().toString().trim();

                int selectedSpeciesId = rgSpecies.getCheckedRadioButtonId();
                if (selectedSpeciesId == -1) {
                    Toast.makeText(this, getString(R.string.fields_required),
                            Toast.LENGTH_SHORT).show();
                    return;
                }

                RadioButton rbSpecies = dialogView.findViewById(selectedSpeciesId);
                String species = rbSpecies.getText().toString();

                if (name.isEmpty() || breed.isEmpty() || age.isEmpty()) {
                    Toast.makeText(this, getString(R.string.fields_required),
                            Toast.LENGTH_SHORT).show();
                    return;
                }

                addPet(name, species, breed, age, medicalHistory);
                dialog.dismiss();
            });
        });

        dialog.show();
    }

    private void addPet(String name, String species, String breed, String age, String medicalHistory) {
        progressBar.setVisibility(View.VISIBLE);

        // Obtener nombre del dueño
        executorService.execute(() -> {
            db.collection("users")
                    .document(currentUserId)
                    .get()
                    .addOnSuccessListener(documentSnapshot -> {
                        String ownerName = documentSnapshot.getString("fullName");
                        Pet pet = new Pet(name, species, breed, age,
                                currentUserId, ownerName, medicalHistory);

                        db.collection("pets")
                                .add(pet)
                                .addOnSuccessListener(documentReference -> {
                                    runOnUiThread(() -> {
                                        progressBar.setVisibility(View.GONE);
                                        Toast.makeText(PetsActivity.this,
                                                getString(R.string.success),
                                                Toast.LENGTH_SHORT).show();
                                        loadPets();
                                    });
                                })
                                .addOnFailureListener(e -> {
                                    runOnUiThread(() -> {
                                        progressBar.setVisibility(View.GONE);
                                        Toast.makeText(PetsActivity.this,
                                                getString(R.string.error),
                                                Toast.LENGTH_SHORT).show();
                                    });
                                });
                    });
        });
    }

    @Override
    public void onEditClick(Pet pet) {
        showEditPetDialog(pet);
    }

    private void showEditPetDialog(Pet pet) {
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_add_pet, null);

        EditText etName = dialogView.findViewById(R.id.etPetName);
        EditText etBreed = dialogView.findViewById(R.id.etPetBreed);
        EditText etAge = dialogView.findViewById(R.id.etPetAge);
        EditText etMedicalHistory = dialogView.findViewById(R.id.etMedicalHistory);
        RadioGroup rgSpecies = dialogView.findViewById(R.id.rgSpecies);

        // Cargar datos actuales
        etName.setText(pet.getName());
        etBreed.setText(pet.getBreed());
        etAge.setText(pet.getAge());
        etMedicalHistory.setText(pet.getMedicalHistory());

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(getString(R.string.edit_pet))
                .setView(dialogView)
                .setPositiveButton(getString(R.string.update), null)
                .setNegativeButton(getString(R.string.cancel), null)
                .create();

        dialog.setOnShowListener(dialogInterface -> {
            Button btnUpdate = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
            btnUpdate.setOnClickListener(v -> {
                pet.setName(etName.getText().toString().trim());
                pet.setBreed(etBreed.getText().toString().trim());
                pet.setAge(etAge.getText().toString().trim());
                pet.setMedicalHistory(etMedicalHistory.getText().toString().trim());
                pet.setUpdatedAt(System.currentTimeMillis());

                updatePet(pet);
                dialog.dismiss();
            });
        });

        dialog.show();
    }

    private void updatePet(Pet pet) {
        progressBar.setVisibility(View.VISIBLE);

        executorService.execute(() -> {
            db.collection("pets")
                    .document(pet.getId())
                    .set(pet)
                    .addOnSuccessListener(aVoid -> {
                        runOnUiThread(() -> {
                            progressBar.setVisibility(View.GONE);
                            Toast.makeText(PetsActivity.this,
                                    getString(R.string.success),
                                    Toast.LENGTH_SHORT).show();
                            loadPets();
                        });
                    })
                    .addOnFailureListener(e -> {
                        runOnUiThread(() -> {
                            progressBar.setVisibility(View.GONE);
                            Toast.makeText(PetsActivity.this,
                                    getString(R.string.error),
                                    Toast.LENGTH_SHORT).show();
                        });
                    });
        });
    }

    @Override
    public void onDeleteClick(Pet pet) {
        new AlertDialog.Builder(this)
                .setTitle(getString(R.string.delete_pet))
                .setMessage(getString(R.string.delete_confirmation))
                .setPositiveButton(getString(R.string.yes), (dialog, which) -> deletePet(pet))
                .setNegativeButton(getString(R.string.no), null)
                .show();
    }

    private void deletePet(Pet pet) {
        progressBar.setVisibility(View.VISIBLE);

        executorService.execute(() -> {
            db.collection("pets")
                    .document(pet.getId())
                    .delete()
                    .addOnSuccessListener(aVoid -> {
                        runOnUiThread(() -> {
                            progressBar.setVisibility(View.GONE);
                            Toast.makeText(PetsActivity.this,
                                    getString(R.string.success),
                                    Toast.LENGTH_SHORT).show();
                            loadPets();
                        });
                    })
                    .addOnFailureListener(e -> {
                        runOnUiThread(() -> {
                            progressBar.setVisibility(View.GONE);
                            Toast.makeText(PetsActivity.this,
                                    getString(R.string.error),
                                    Toast.LENGTH_SHORT).show();
                        });
                    });
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (executorService != null && !executorService.isShutdown()) {
            executorService.shutdown();
        }
    }
}