package com.example.vetmanager.activities;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.vetmanager.R;
import com.example.vetmanager.models.User;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class RegisterActivity extends AppCompatActivity {

    private EditText etEmail, etPassword, etFullName, etPhone, etAddress;
    private RadioGroup rgRole;
    private Button btnRegister, btnCancel;
    private ProgressBar progressBar;
    private FirebaseAuth mAuth;
    private FirebaseFirestore db;
    private ExecutorService executorService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        initializeViews();
        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();
        executorService = Executors.newSingleThreadExecutor();

        setupListeners();
    }

    private void initializeViews() {
        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        etFullName = findViewById(R.id.etFullName);
        etPhone = findViewById(R.id.etPhone);
        etAddress = findViewById(R.id.etAddress);
        rgRole = findViewById(R.id.rgRole);
        btnRegister = findViewById(R.id.btnRegister);
        btnCancel = findViewById(R.id.btnCancel);
        progressBar = findViewById(R.id.progressBar);
    }

    private void setupListeners() {
        btnRegister.setOnClickListener(v -> registerUser());
        btnCancel.setOnClickListener(v -> finish());
    }

    private void registerUser() {
        String email = etEmail.getText().toString().trim();
        String password = etPassword.getText().toString().trim();
        String fullName = etFullName.getText().toString().trim();
        String phone = etPhone.getText().toString().trim();
        String address = etAddress.getText().toString().trim();

        int selectedRoleId = rgRole.getCheckedRadioButtonId();
        if (selectedRoleId == -1) {
            Toast.makeText(this, getString(R.string.fields_required), Toast.LENGTH_SHORT).show();
            return;
        }

        RadioButton rbRole = findViewById(selectedRoleId);
        String role = rbRole.getText().toString().toLowerCase();

        if (!validateInputs(email, password, fullName, phone, address)) {
            return;
        }

        setLoadingState(true);

        // Verificar duplicados en hilo secundario
        executorService.execute(() -> {
            db.collection("users")
                    .whereEqualTo("email", email)
                    .get()
                    .addOnCompleteListener(task -> {
                        if (task.isSuccessful()) {
                            QuerySnapshot querySnapshot = task.getResult();
                            if (querySnapshot != null && !querySnapshot.isEmpty()) {
                                runOnUiThread(() -> {
                                    setLoadingState(false);
                                    Toast.makeText(RegisterActivity.this,
                                            getString(R.string.email_already_exists),
                                            Toast.LENGTH_LONG).show();
                                });
                            } else {
                                createUserAccount(email, password, fullName, phone, address, role);
                            }
                        } else {
                            runOnUiThread(() -> {
                                setLoadingState(false);
                                Toast.makeText(RegisterActivity.this,
                                        getString(R.string.error),
                                        Toast.LENGTH_SHORT).show();
                            });
                        }
                    });
        });
    }

    private void createUserAccount(String email, String password, String fullName,
                                   String phone, String address, String role) {
        executorService.execute(() -> {
            mAuth.createUserWithEmailAndPassword(email, password)
                    .addOnCompleteListener(task -> {
                        if (task.isSuccessful() && mAuth.getCurrentUser() != null) {
                            String uid = mAuth.getCurrentUser().getUid();
                            User user = new User(uid, email, fullName, phone, address, role);
                            saveUserToFirestore(user);
                        } else {
                            runOnUiThread(() -> {
                                setLoadingState(false);
                                String errorMsg = task.getException() != null ?
                                        task.getException().getMessage() :
                                        getString(R.string.error);
                                Toast.makeText(RegisterActivity.this,
                                        errorMsg,
                                        Toast.LENGTH_LONG).show();
                            });
                        }
                    });
        });
    }

    private void saveUserToFirestore(User user) {
        db.collection("users")
                .document(user.getUid())
                .set(user)
                .addOnCompleteListener(task -> {
                    runOnUiThread(() -> {
                        setLoadingState(false);
                        if (task.isSuccessful()) {
                            Toast.makeText(RegisterActivity.this,
                                    getString(R.string.success),
                                    Toast.LENGTH_SHORT).show();
                            finish();
                        } else {
                            Toast.makeText(RegisterActivity.this,
                                    getString(R.string.error),
                                    Toast.LENGTH_SHORT).show();
                        }
                    });
                });
    }

    private boolean validateInputs(String email, String password, String fullName,
                                   String phone, String address) {
        if (TextUtils.isEmpty(email) || TextUtils.isEmpty(password) ||
                TextUtils.isEmpty(fullName) || TextUtils.isEmpty(phone) ||
                TextUtils.isEmpty(address)) {
            Toast.makeText(this, getString(R.string.fields_required), Toast.LENGTH_SHORT).show();
            return false;
        }

        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            etEmail.setError(getString(R.string.invalid_email));
            return false;
        }

        if (password.length() < 6) {
            etPassword.setError(getString(R.string.weak_password));
            return false;
        }

        return true;
    }

    private void setLoadingState(boolean isLoading) {
        progressBar.setVisibility(isLoading ? View.VISIBLE : View.GONE);
        btnRegister.setEnabled(!isLoading);
        btnCancel.setEnabled(!isLoading);
        etEmail.setEnabled(!isLoading);
        etPassword.setEnabled(!isLoading);
        etFullName.setEnabled(!isLoading);
        etPhone.setEnabled(!isLoading);
        etAddress.setEnabled(!isLoading);
        rgRole.setEnabled(!isLoading);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (executorService != null && !executorService.isShutdown()) {
            executorService.shutdown();
        }
    }
}