package com.example.vetmanager.models;

public class Pet {
    private String id;
    private String name;
    private String species; // dog, cat, bird, other
    private String breed;
    private String age;
    private String ownerId;
    private String ownerName;
    private String medicalHistory;
    private long createdAt;
    private long updatedAt;

    public Pet() {
        // Constructor vacío requerido por Firebase
    }

    public Pet(String name, String species, String breed, String age,
               String ownerId, String ownerName, String medicalHistory) {
        this.name = name;
        this.species = species;
        this.breed = breed;
        this.age = age;
        this.ownerId = ownerId;
        this.ownerName = ownerName;
        this.medicalHistory = medicalHistory;
        this.createdAt = System.currentTimeMillis();
        this.updatedAt = System.currentTimeMillis();
    }

    // Getters
    public String getId() { return id; }
    public String getName() { return name; }
    public String getSpecies() { return species; }
    public String getBreed() { return breed; }
    public String getAge() { return age; }
    public String getOwnerId() { return ownerId; }
    public String getOwnerName() { return ownerName; }
    public String getMedicalHistory() { return medicalHistory; }
    public long getCreatedAt() { return createdAt; }
    public long getUpdatedAt() { return updatedAt; }

    // Setters
    public void setId(String id) { this.id = id; }
    public void setName(String name) { this.name = name; }
    public void setSpecies(String species) { this.species = species; }
    public void setBreed(String breed) { this.breed = breed; }
    public void setAge(String age) { this.age = age; }
    public void setOwnerId(String ownerId) { this.ownerId = ownerId; }
    public void setOwnerName(String ownerName) { this.ownerName = ownerName; }
    public void setMedicalHistory(String medicalHistory) { this.medicalHistory = medicalHistory; }
    public void setCreatedAt(long createdAt) { this.createdAt = createdAt; }
    public void setUpdatedAt(long updatedAt) { this.updatedAt = updatedAt; }
}